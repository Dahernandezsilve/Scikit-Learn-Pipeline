# Exporta el punto de entrada para uso programático si lo deseas
from .main import main

__all__ = ["main"]
